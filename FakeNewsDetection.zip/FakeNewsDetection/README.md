# Fake-Review-Detection-

- [Problem Statement](#problem-statement)
- [Contributors](#contributors)

> Fake Review Detection using Machine Learning

## Problem Statement 

Problem Statement - Fake Review detection on 20 Chicago Hotel Review Dataset using various supervised Machine Learning Techniques and classify the review whether it is fake or real.

## contributors

- [Priyanshu Singh](https://github.com/reveurguy) - Frontend part
- [Shubham Pawar](https://github.com/shubham5351) - ML Part
- [Rutuja Nemane](https://github.com/rutujanemane) - Deployment using Flask
